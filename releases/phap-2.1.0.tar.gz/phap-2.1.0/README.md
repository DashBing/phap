# phap
Programing Helpful Algorithm Package

## Links
[Github](https://github.com/DashBing/phap/ "Github")
[Pypi](https://pypi.org/project/phap/ "Pypi")
[Pypi (stralgo)](https://pypi.org/project/stralgo/ "Pypi (stralgo)")

# Versions
## Stable
+ v0.1.0 (stralgo)
+ v1.1.1 (stralgo)
+ v2.1.0

# Build
## On Windows
```make build```
